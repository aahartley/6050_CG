//
//		          Programming Assignment #1
//
//					Daljit Singh Dhillon
//
//
/***************************************************************************/
/* Include needed files */



/***************************************************************************/
// Forward declarations
void drawPixel(int x, int y);

void drawLineDDA(float xStart, float yStart, float xEnd, float yEnd);
void drawLineBresenham(int xStart, int yStart, int xEnd, int yEnd);
void drawThickLineBresenham(int xStart, int yStart, int xEnd, int yEnd, int lineWidth);
void drawLineSlopeIntercept(float slope, float yIntercept);
void draw2dAxesAndSquare(float orgX, float orgY, float xVecE1, float xVecE2, float yVecE1, float yVecE2, float sqrBaseX, float sqrBaseY, float sqrWidth);
void draw3dAxesAndCube(float orgX, float orgY, float xVecE1, float xVecE2, float yVecE1, float yVecE2, float zVecE1, float zVecE2, float cubeBaseX, float cubeBaseY, float cubeBaseZ, float cubeWidth);
void drawStyleDottedLine(float xStart, float yStart, float xEnd, float yEnd, int lineWidth);
void drawStyleDashedLine(float xStart, float yStart, float xEnd, float yEnd, int lineWidth);
void drawStyleDotAndDashLine(float xStart, float yStart, float xEnd, float yEnd, int lineWidth);

void drawLineDDA(float xStart, float yStart, float xEnd, float yEnd)
{
	drawPixel((int)xStart,(int)yStart);
	drawPixel((int)xEnd, (int)yEnd);

	//replace above two lines with your own inplementation
}

void drawLineBresenham(int xStart, int yStart, int xEnd, int yEnd)
{
	drawPixel((int)xStart,(int)yStart);
	drawPixel((int)xEnd, (int)yEnd);

	//replace above two lines with your own inplementation
}

void drawThickLineBresenham(int xStart, int yStart, int xEnd, int yEnd, int lineWidth)
{
	drawPixel((int)xStart,(int)yStart);
	drawPixel((int)xEnd, (int)yEnd);

	//replace above two lines with your own inplementation
}

void drawStyleDottedLine(float xStart, float yStart, float xEnd, float yEnd, int lineWidth)
{
	drawPixel((int)xStart,(int)yStart);
	drawPixel((int)xEnd, (int)yEnd);

	//replace above two lines with your own inplementation
}

void drawStyleDashedLine(float xStart, float yStart, float xEnd, float yEnd, int lineWidth)
{
	drawPixel((int)xStart,(int)yStart);
	drawPixel((int)xEnd, (int)yEnd);

	//replace above two lines with your own inplementation
}

void drawStyleDotAndDashLine(float xStart, float yStart, float xEnd, float yEnd, int lineWidth)
{
	drawPixel((int)xStart,(int)yStart);
	drawPixel((int)xEnd, (int)yEnd);

	//replace above two lines with your own inplementation
}


void drawLineSlopeIntercept(float slope, float yIntercept)
{
	drawPixel((int)yIntercept,(int)yIntercept);
	drawPixel((int)yIntercept, (int)yIntercept);

	//replace above two lines with your own inplementation
}
void draw2dAxesAndSquare(float orgX, float orgY,
						 float xVecE1, float xVecE2,
						 float yVecE1, float yVecE2,
						 float cubeBaseX, float cubeBaseY, float cubeWidth)
{
	drawPixel((int)orgX,(int)orgY);
	drawPixel((int)orgX, (int)orgY);

	//replace above two lines with your own inplementation
}
void draw3dAxesAndCube(float orgX, float orgY,
					   float xVecE1, float xVecE2,
					   float yVecE1, float yVecE2,
					   float zVecE1, float zVecE2,
					   float cubeBaseX, float cubeBaseY, float cubeBaseZ, float cubeWidth)
{
	drawPixel((int)orgX,(int)orgY);
	drawPixel((int)orgX, (int)orgY);

	//replace above two lines with your own inplementation
}


